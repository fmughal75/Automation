# Deployment Guide (CML 10.10.20.161 + Devbox 10.10.20.50)

## Server info (as provided)
### Cisco Modeling Labs (CML)
- Address: 10.10.20.161
- Username: developer
- Password: C1sco12345
- HTTPS Port: 443
- GUI/API URL: https://10.10.20.161
- SSH Port: 22

### Devbox (jump host)
- Address: 10.10.20.50
- Username: developer
- Password: C1sco12345
- SSH Port: 22
- RDP Port: 3389

### Node credentials (inside CML by default)
- Username: cisco
- Password: cisco

---

## Step-by-step deployment

### 1) Log into Devbox
```bash
ssh developer@10.10.20.50
```

### 2) Prepare Python environment
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 3) Configure environment variables
```bash
cp env.example .env
nano .env
source .env
```

### 4) Import the lab into CML

#### Option A: Import using the CML GUI
1. Open: https://10.10.20.161
2. Go to **Labs** → **Import**
3. Upload: `cml_lab.yaml`
4. Open the imported lab and press **Start**
5. Copy the lab ID (from the lab URL or lab details) and paste into `.env` as `CML_LAB_ID`

#### Option B: Import & start via script (CML API)
```bash
source .env
python utils/cml_import_start.py
```
The script prints `LAB_ID=...` — paste that into `.env` as `CML_LAB_ID`.

### 5) Run the certification pipeline (pyATS)
```bash
source .env
pyats run job job.py
```

---

## IxNetwork VE / Virtual Ports

This package includes RESTPy-based IxNetwork VE integration:
- `ixnetwork_restpy_traffic.py`

### If you have IxNetwork VE ready
Set these in `.env`:
- `IXN_HOST` (IxNetwork API host/IP)
- `IXN_USERNAME` / `IXN_PASSWORD`

### If not available
Leave `IXN_HOST` empty — the traffic gate step will be **skipped**.

