# mini-e2e-cert-lab (CML + IOS-XE eBGP Underlay + EVPN/VXLAN + pyATS + IxNetwork VE)

This repository is a **mini platform-certification lab** designed for:
- **CML** for topology + IOS-XE nodes
- **pyATS/Genie** for configuration + validation
- **IxNetwork VE / IxNetwork API** for traffic generation & pass/fail gating (virtual ports)

## Folder layout

```text
mini-e2e-cert-lab/
├── README.md
├── DEPLOYMENT_GUIDE.md
├── requirements.txt
├── cml_lab.yaml
├── env.example
├── job.py
├── test_evpn_vxlan.py
├── ixnetwork_restpy_traffic.py
├── utils/
│   ├── cml_import_start.py
│   └── build_testbed.py
└── configs/
    ├── SPINE1.cfg
    ├── LEAF1.cfg
    └── LEAF2.cfg
```

## What this lab validates
1. **Underlay eBGP** adjacencies (SPINE1 <-> LEAF1/LEAF2)
2. **EVPN BGP** adjacency and IMET route presence (Type-3)
3. **VXLAN/NVE** peer reachability
4. **MAC learning** (VLAN 100) – command/visibility checks (expandable to real MAC learning)
5. **Traffic gating** via IxNetwork: loss% and throughput thresholds
6. **Failure injection**: interface flap → re-convergence → traffic loss/throughput gate

## Quick start (Devbox)
1. SSH to Devbox: `ssh developer@10.10.20.50`
2. Install Python dependencies:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
3. Copy and edit env file:
   ```bash
   cp env.example .env
   # edit .env to set CML_LAB_ID after import
   source .env
   ```
4. Import lab into CML (GUI or script):
   - GUI: CML → Labs → Import → select `cml_lab.yaml`
   - OR: `python utils/cml_import_start.py`
5. Run the certification job:
   ```bash
   pyats run job job.py
   ```

## Notes
- Device credentials inside CML nodes are assumed **cisco/cisco** by default.
- The job auto-discovers node management IPs from the CML API.
- If your Devbox cannot route to node management IPs, adapt connections to use CML console.

