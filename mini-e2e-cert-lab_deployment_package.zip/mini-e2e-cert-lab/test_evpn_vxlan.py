import os
import re
import time
from pyats import aetest
from ixnetwork_restpy_traffic import IxTrafficRestPyVE

def load_cfg(path):
    with open(path, "r", encoding="utf-8") as f:
        return [line.rstrip("\n") for line in f.readlines() if line.strip()]

def must_have(pattern, text, msg):
    if not re.search(pattern, text, re.IGNORECASE | re.MULTILINE):
        raise AssertionError(msg)

def flap_interface(device, interface: str, down_s=5):
    device.configure([f"interface {interface}", "shutdown"])
    time.sleep(down_s)
    device.configure([f"interface {interface}", "no shutdown"])

def wait_bgp_established(device, neighbor_ip: str, timeout_s=120):
    start = time.time()
    while time.time() - start < timeout_s:
        out = device.execute("show bgp ipv4 unicast summary")
        if re.search(rf"^{re.escape(neighbor_ip)}\s+.*(Estab|Established|\d+)\s*$", out, re.MULTILINE):
            return True
        time.sleep(5)
    return False

def wait_nve_peer_up(device, vtep_ip: str, timeout_s=180):
    start = time.time()
    while time.time() - start < timeout_s:
        out = device.execute("show nve peers")
        if re.search(rf"{re.escape(vtep_ip)}.*\bUp\b", out, re.IGNORECASE):
            return True
        time.sleep(5)
    return False

class CommonSetup(aetest.CommonSetup):
    @aetest.subsection
    def connect(self, testbed):
        testbed.connect(log_stdout=False, learn_hostname=True)

class ConfigureDevices(aetest.Testcase):
    @aetest.test
    def push_configs(self, testbed):
        base = os.path.join(os.path.dirname(__file__), "configs")
        for dev_name, cfg_file in [("SPINE1","SPINE1.cfg"),("LEAF1","LEAF1.cfg"),("LEAF2","LEAF2.cfg")]:
            dev = testbed.devices[dev_name]
            cfg = load_cfg(os.path.join(base, cfg_file))
            dev.configure(cfg)

class ValidateControlPlane(aetest.Testcase):
    @aetest.test
    def bgp_underlay_up(self, testbed):
        spine = testbed.devices["SPINE1"]
        out = spine.execute("show bgp ipv4 unicast summary")
        must_have(r"10\.0\.0\.1", out, "Missing LEAF1 neighbor (underlay) in BGP summary")
        must_have(r"10\.0\.0\.3", out, "Missing LEAF2 neighbor (underlay) in BGP summary")
        must_have(r"Estab|Established", out, "Underlay BGP not established")

    @aetest.test
    def bgp_evpn_up(self, testbed):
        spine = testbed.devices["SPINE1"]
        out = spine.execute("show bgp l2vpn evpn summary")
        must_have(r"10\.0\.0\.1", out, "Missing LEAF1 neighbor in EVPN summary")
        must_have(r"10\.0\.0\.3", out, "Missing LEAF2 neighbor in EVPN summary")
        must_have(r"Estab|Established", out, "EVPN BGP not established")

class ValidateVXLANEVPN(aetest.Testcase):
    @aetest.test
    def nve_peers_up(self, testbed):
        leaf1 = testbed.devices["LEAF1"]
        out = leaf1.execute("show nve peers")
        must_have(r"10\.255\.2\.2", out, "LEAF2 VTEP not seen in NVE peers on LEAF1")
        must_have(r"\bUp\b", out, "NVE peer not Up")

    @aetest.test
    def evpn_imet_present(self, testbed):
        leaf1 = testbed.devices["LEAF1"]
        out = leaf1.execute("show bgp l2vpn evpn route-type 3")
        must_have(r"10100", out, "EVPN IMET (type-3) for VNI 10100 not present")

class ValidateMacLearning(aetest.Testcase):
    @aetest.test
    def mac_table_vlan100(self, testbed):
        leaf1 = testbed.devices["LEAF1"]
        out = leaf1.execute("show mac address-table dynamic vlan 100")
        must_have(r"100", out, "MAC table for VLAN 100 not visible / empty output")

class TrafficAndFailureGate(aetest.Testcase):
    @aetest.test
    def traffic_gate_with_flap(self, testbed, ixn_host="", ixn_username="admin", ixn_password="admin"):
        if not ixn_host:
            self.skipped("IXN_HOST not set; skipping IxNetwork traffic gate test.")

        leaf1 = testbed.devices["LEAF1"]

        ix = IxTrafficRestPyVE(ixn_host, username=ixn_username, password=ixn_password, verify_ssl=False)
        ix.create_virtual_ports()
        ix.build_l2_vlan_traffic(vlan_id=100, frame_size=512, rate_percent=20)

        ix.start_traffic()
        time.sleep(8)
        pre = ix.get_flow_stats()
        if pre.get("loss_pct") is None:
            ix.stop_traffic()
            self.failed(f"IxNetwork stats not parsed. Raw: {pre}")

        flap_interface(leaf1, "GigabitEthernet1", down_s=5)

        if not wait_bgp_established(leaf1, "10.0.0.0", timeout_s=120):
            ix.stop_traffic()
            self.failed("BGP did not re-establish on LEAF1 after link flap")

        if not wait_nve_peer_up(leaf1, "10.255.2.2", timeout_s=180):
            ix.stop_traffic()
            self.failed("NVE peer did not become Up after link flap")

        time.sleep(10)
        post = ix.get_flow_stats()
        ix.stop_traffic()

        max_post_loss_pct = 0.05
        min_post_thr_gbps = max(0.8 * pre["throughput_gbps"], 0.1)

        if post["loss_pct"] > max_post_loss_pct:
            self.failed(f"Post-recovery loss {post['loss_pct']}% > {max_post_loss_pct}%")
        if post["throughput_gbps"] < min_post_thr_gbps:
            self.failed(f"Post-recovery throughput {post['throughput_gbps']}Gbps < {min_post_thr_gbps}Gbps")

class CommonCleanup(aetest.CommonCleanup):
    @aetest.subsection
    def disconnect(self, testbed):
        testbed.disconnect()
