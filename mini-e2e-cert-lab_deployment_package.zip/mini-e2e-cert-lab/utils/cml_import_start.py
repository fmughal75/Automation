import os
from virl2_client import ClientLibrary

def main():
    cml = ClientLibrary(os.environ["CML_URL"], os.environ["CML_USER"], os.environ["CML_PASS"], ssl_verify=False)

    lab_path = os.path.join(os.path.dirname(__file__), "..", "cml_lab.yaml")
    with open(lab_path, "r", encoding="utf-8") as f:
        lab_yaml = f.read()

    lab = cml.import_lab(lab_yaml)
    print(f"Imported lab. LAB_ID={lab.id}")
    lab.start()
    print("Started lab.")

if __name__ == "__main__":
    main()
