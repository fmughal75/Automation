import os
import time
from pyats.easypy import run
from virl2_client import ClientLibrary
from genie.testbed import load

def cml_connect():
    return ClientLibrary(
        os.environ["CML_URL"],
        os.environ["CML_USER"],
        os.environ["CML_PASS"],
        ssl_verify=False
    )

def start_lab_and_get_mgmt_ips(cml, lab_id: str) -> dict:
    lab = cml.join_existing_lab(lab_id)
    lab.start()
    time.sleep(5)

    nodes = lab.nodes()
    mgmt = {}
    for n in nodes:
        if n.label in ("SPINE1", "LEAF1", "LEAF2"):
            mgmt[n.label] = n.management_ip
    return mgmt

def build_testbed(mgmt_ips: dict):
    node_user = os.environ.get("NODE_USER", "cisco")
    node_pass = os.environ.get("NODE_PASS", "cisco")
    tb_dict = {
        "testbed": {"name": "cml-iosxe-evpn", "credentials": {"default": {"username": node_user, "password": node_pass}}},
        "devices": {}
    }
    for name, ip in mgmt_ips.items():
        tb_dict["devices"][name] = {
            "os": "iosxe",
            "type": "router",
            "connections": {"cli": {"protocol": "ssh", "ip": ip}}
        }
    return load(tb_dict)

def main(runtime):
    cml = cml_connect()
    lab_id = os.environ["CML_LAB_ID"]

    mgmt_ips = start_lab_and_get_mgmt_ips(cml, lab_id)
    if set(mgmt_ips.keys()) != {"SPINE1", "LEAF1", "LEAF2"}:
        raise RuntimeError(f"Could not discover all nodes. Found: {mgmt_ips}")

    runtime.testbed = build_testbed(mgmt_ips)
    runtime.parameters["ixn_host"] = os.environ.get("IXN_HOST", "")
    runtime.parameters["ixn_username"] = os.environ.get("IXN_USERNAME", "admin")
    runtime.parameters["ixn_password"] = os.environ.get("IXN_PASSWORD", "admin")

    run(testscript="test_evpn_vxlan.py", testbed=runtime.testbed)
