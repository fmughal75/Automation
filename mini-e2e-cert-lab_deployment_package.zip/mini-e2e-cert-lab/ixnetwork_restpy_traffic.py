from dataclasses import dataclass
from typing import Dict, Any
import time
from ixnetwork_restpy import SessionAssistant

@dataclass
class IxiaVirtualPorts:
    vport_a_name: str = "vportA"
    vport_b_name: str = "vportB"

class IxTrafficRestPyVE:
    def __init__(self, ixnetwork_host: str, username="admin", password="admin", verify_ssl=False):
        self.sa = SessionAssistant(
            IpAddress=ixnetwork_host,
            RestPort=443,
            UserName=username,
            Password=password,
            LogLevel="info",
            ClearConfig=True,
            VerifySslCert=verify_ssl,
        )
        self.ixn = self.sa.Ixnetwork

    def create_virtual_ports(self, ports: IxiaVirtualPorts = IxiaVirtualPorts()):
        self.ixn.Vport.add(Name=ports.vport_a_name)
        self.ixn.Vport.add(Name=ports.vport_b_name)

    def build_l2_vlan_traffic(self, vlan_id=100, frame_size=512, rate_percent=10):
        topo = self.ixn.Topology
        topo.add(Name="TopoA", Vports=self.ixn.Vport.find(Name="vportA"))
        topo.add(Name="TopoB", Vports=self.ixn.Vport.find(Name="vportB"))

        topoA = topo.find(Name="TopoA")
        topoB = topo.find(Name="TopoB")

        dgA = topoA.DeviceGroup.add(Name="DG_A", Multiplier=1)
        dgB = topoB.DeviceGroup.add(Name="DG_B", Multiplier=1)

        ethA = dgA.Ethernet.add(Name="EthA")
        ethB = dgB.Ethernet.add(Name="EthB")

        vlanA = ethA.Vlan.add(Name="VLAN_A")
        vlanB = ethB.Vlan.add(Name="VLAN_B")
        vlanA.VlanId.Single(vlan_id)
        vlanB.VlanId.Single(vlan_id)

        ethA.Mac.Increment(start_value="00:11:01:00:00:01", step_value="00:00:00:00:00:01")
        ethB.Mac.Increment(start_value="00:11:02:00:00:01", step_value="00:00:00:00:00:01")

        self.ixn.StartAllProtocols(Arg1="sync")
        time.sleep(2)

        ti = self.ixn.Traffic.TrafficItem.add(
            Name="L2_VLAN100_BiDi",
            TrafficType="ethernetVlan",
            BiDirectional=True
        )
        ti.EndpointSet.add(Sources=dgA, Destinations=dgB)

        cfg = ti.ConfigElement.find()
        cfg.FrameSize.FixedSize = frame_size
        cfg.TransmissionControl.Type = "percentage"
        cfg.TransmissionControl.Percentage = rate_percent

        self.ixn.Traffic.Generate()

    def start_traffic(self):
        self.ixn.Traffic.Apply()
        self.ixn.Traffic.Start()
        time.sleep(2)

    def stop_traffic(self):
        self.ixn.Traffic.Stop()
        time.sleep(1)

    def get_flow_stats(self) -> Dict[str, Any]:
        view = self.ixn.Statistics.View.find(Caption="Flow Statistics")
        view.Refresh()

        col_names = [c.DisplayName for c in view.Column]
        rows = list(view.Row)

        def col_idx(cands):
            for c in cands:
                if c in col_names:
                    return col_names.index(c)
            return None

        loss_idx = col_idx(["Loss %", "Loss Percentage", "Frames Loss %"])
        rx_rate_idx = col_idx(["Rx Rate (bps)", "Rx Rate (bit/s)", "Rx Rate"])
        if loss_idx is None or rx_rate_idx is None or not rows:
            return {"raw_columns": col_names, "raw_rows": rows[:3], "loss_pct": None, "throughput_gbps": None}

        loss_vals = []
        rx_bps_total = 0.0
        for r in rows:
            try:
                loss_vals.append(float(r[loss_idx]))
            except Exception:
                pass
            try:
                rx_bps_total += float(r[rx_rate_idx])
            except Exception:
                pass

        loss_pct = sum(loss_vals) / max(len(loss_vals), 1)
        throughput_gbps = rx_bps_total / 1e9
        return {"loss_pct": loss_pct, "throughput_gbps": throughput_gbps}
